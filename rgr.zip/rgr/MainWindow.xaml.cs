﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Shapes;
using System.Diagnostics;
using System.Windows.Threading;

namespace RGR // <-- ВАЖЛИВО: ПЕРЕВІРТЕ, ЧИ НАЗВА ВАШОГО ПРОЕКТУ ДІЙСНО RGR
{
    public partial class MainWindow : Window
    {
        // Конфігурація гри
        private const int CellSize = 40; // Розмір однієї клітинки в пікселях
        private int winLength = 4; // Довжина лінії для перемоги (за замовчуванням)

        // Стан ігрової дошки
        private Dictionary<(int x, int y), char> board = new(); // Зберігання символів за координатами

        // Історія ходів для функцій Undo/Redo
        private Stack<((int x, int y) pos, char player)> undoStack = new(); // Виконані ходи
        private Stack<((int x, int y) pos, char player)> redoStack = new(); // Для повтору скасованих ходів

        // Поточний гравець
        private char currentPlayer = 'X'; // 'X' завжди починає

        // Генератор випадкових чисел для AI
        private Random random = new Random();

        // Межі зайнятої частини дошки (для відображення та AI пошуку)
        private int minBoardX = 0, maxBoardX = 0, minBoardY = 0, maxBoardY = 0;

        // Зсув Canvas для відображення від'ємних координат
        // Це компенсує клік миші та малювання символів на Canvas
        private double canvasOffsetX = 0;
        private double canvasOffsetY = 0;

        // Флаг, щоб уникнути повторної ініціалізації гри
        private bool _isGameInitialized = false;

        // Конструктор: Викликається, коли створюється екземпляр MainWindow.
        public MainWindow()
        {
            InitializeComponent(); // Цей метод завантажує XAML та створює об'єкти UI.
            // Примітка: UI елементи ще не повністю доступні тут.
        }

        // Обробник події Loaded для всього вікна.
        // Викликається після того, як вікно та всі його дочірні елементи були завантажені
        // і готові до відображення.
        private void MainWindow_Loaded(object sender, RoutedEventArgs e)
        {
            if (_isGameInitialized) return; // Якщо вже ініціалізовано, виходимо.

            // Прив'язуємо обробники подій.
            // Робіть це тут, після InitializeComponent(), коли елементи UI гарантовано доступні.
            if (GameModeBox != null) GameModeBox.SelectionChanged += GameModeBox_SelectionChanged;
            if (WinLengthBox != null) WinLengthBox.TextChanged += WinLengthBox_TextChanged;
            if (GameCanvas != null) GameCanvas.MouseLeftButtonDown += GameCanvas_MouseLeftButtonDown;


            // Встановлюємо початкові значення для елементів керування.
            if (WinLengthBox != null) WinLengthBox.Text = "4";
            if (GameModeBox != null) GameModeBox.SelectedIndex = 0; // "2 гравці"

            // Відкладаємо початкове налаштування гри
            // до моменту, коли система буде повністю бездіяльною.
            // Це гарантує, що GameCanvas та інші елементи точно проініціалізовані
            // та готові до взаємодії (малювання, вимірювання розмірів тощо).
            Dispatcher.BeginInvoke(new Action(InitialGameSetup), DispatcherPriority.ApplicationIdle);

            _isGameInitialized = true; // Встановлюємо флаг, що гра ініціалізована.
        }

        /// <summary>
        /// Метод для первинного налаштування гри. Викликається після повного завантаження UI.
        /// </summary>
        private void InitialGameSetup()
        {
            Debug.WriteLine("InitialGameSetup: Called.");
            // Перевіряємо, чи всі критичні елементи UI доступні.
            if (GameCanvas == null || CurrentPlayerTextBlock == null || WinLengthBox == null || GameModeBox == null)
            {
                Debug.WriteLine("[ERROR] InitialGameSetup: One or more critical UI elements are null. Cannot proceed with game setup.");
                return;
            }
            ResetGame(); // Запускаємо скидання гри, яке включає перше малювання.
        }

        /// <summary>
        /// Малює сітку ігрового поля на Canvas.
        /// </summary>
        private void DrawBoardGrid()
        {
            if (GameCanvas == null)
            {
                Debug.WriteLine("[ERROR] DrawBoardGrid: GameCanvas is null. Cannot draw grid.");
                return;
            }

            // Завжди очищаємо Canvas перед перемалюванням.
            GameCanvas.Children.Clear();

            // Визначаємо діапазон клітинок, які потрібно відобразити, враховуючи буфер.
            int bufferCells = 5; // Додаткові клітинки для видимості навколо зайнятої області

            // Якщо дошка порожня, починаємо з центру (0,0) і додаємо буфер.
            // Інакше розширюємо межі існуючих ходів з буфером.
            int currentViewMinX = board.Any() ? minBoardX - bufferCells : -bufferCells;
            int currentViewMaxX = board.Any() ? maxBoardX + bufferCells : bufferCells;
            int currentViewMinY = board.Any() ? minBoardY - bufferCells : -bufferCells;
            int currentViewMaxY = board.Any() ? maxBoardY + bufferCells : bufferCells;

            // Обчислюємо розміри Canvas, враховуючи, що він має охоплювати всі клітинки
            // від currentViewMin до currentViewMax
            GameCanvas.Width = (currentViewMaxX - currentViewMinX + 1) * CellSize;
            GameCanvas.Height = (currentViewMaxY - currentViewMinY + 1) * CellSize;

            // Визначаємо зсув для малювання на Canvas.
            // Це потрібно, щоб логічна координата (currentViewMinX, currentViewMinY)
            // відображалася в (0,0) Canvas.
            canvasOffsetX = -currentViewMinX * CellSize;
            canvasOffsetY = -currentViewMinY * CellSize;

            // Додатково, переконаємося, що Canvas достатньо великий для видимої області ScrollViewer
            ScrollViewer parentScrollViewer = FindAncestor<ScrollViewer>(GameCanvas);
            if (parentScrollViewer != null)
            {
                // Забезпечуємо, що Canvas не буде меншим за ScrollViewer
                // Використовуємо ActualWidth/Height, якщо вони вже ініціалізовані.
                if (parentScrollViewer.ActualWidth > 0)
                {
                    GameCanvas.Width = Math.Max(GameCanvas.Width, parentScrollViewer.ActualWidth);
                }
                if (parentScrollViewer.ActualHeight > 0)
                {
                    GameCanvas.Height = Math.Max(GameCanvas.Height, parentScrollViewer.ActualHeight);
                }
            }
            else // Якщо ScrollViewer ще не доступний, використовуємо мінімальні розміри
            {
                GameCanvas.Width = Math.Max(GameCanvas.Width, 800); // Мінімальна ширина
                GameCanvas.Height = Math.Max(GameCanvas.Height, 600); // Мінімальна висота
            }

            // Малюємо вертикальні лінії
            for (int x = currentViewMinX; x <= currentViewMaxX + 1; x++)
            {
                Line line = new Line
                {
                    X1 = x * CellSize + canvasOffsetX, // Застосовуємо зсув
                    Y1 = currentViewMinY * CellSize + canvasOffsetY, // Застосовуємо зсув
                    X2 = x * CellSize + canvasOffsetX, // Застосовуємо зсув
                    Y2 = (currentViewMaxY + 1) * CellSize + canvasOffsetY, // Застосовуємо зсув
                    Stroke = Brushes.LightGray,
                    StrokeThickness = 1
                };
                GameCanvas.Children.Add(line);
            }

            // Малюємо горизонтальні лінії
            for (int y = currentViewMinY; y <= currentViewMaxY + 1; y++)
            {
                Line line = new Line
                {
                    X1 = currentViewMinX * CellSize + canvasOffsetX, // Застосовуємо зсув
                    Y1 = y * CellSize + canvasOffsetY, // Застосовуємо зсув
                    X2 = (currentViewMaxX + 1) * CellSize + canvasOffsetX, // Застосовуємо зсув
                    Y2 = y * CellSize + canvasOffsetY, // Застосовуємо зсув
                    Stroke = Brushes.LightGray,
                    StrokeThickness = 1
                };
                GameCanvas.Children.Add(line);
            }
            Debug.WriteLine($"DrawBoardGrid: Canvas Size set to W:{GameCanvas.Width} H:{GameCanvas.Height}");
        }

        /// <summary>
        /// Допоміжний метод для пошуку батьківського елемента певного типу (наприклад, ScrollViewer).
        /// </summary>
        private static T FindAncestor<T>(DependencyObject current) where T : DependencyObject
        {
            do
            {
                current = VisualTreeHelper.GetParent(current);
            }
            while (current != null && !(current is T));
            return current as T;
        }

        /// <summary>
        /// Обробник кліку миші на ігровому полі (Canvas).
        /// </summary>
        private void GameCanvas_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            if (GameCanvas == null)
            {
                Debug.WriteLine("[ERROR] GameCanvas_MouseLeftButtonDown: GameCanvas is null.");
                return;
            }

            // Якщо зараз хід комп'ютера і гравець проти комп'ютера, ігноруємо клік гравця.
            if (currentPlayer == 'O' && IsVsComputer()) return;

            // Перевіряємо та парсимо довжину для перемоги з TextBox.
            if (WinLengthBox == null || !int.TryParse(WinLengthBox.Text, out winLength) || winLength < 3)
            {
                MessageBox.Show("Довжина для перемоги має бути числом більше або рівним 3.", "Помилка введення", MessageBoxButton.OK, MessageBoxImage.Warning);
                if (WinLengthBox != null) WinLengthBox.Text = "4"; // Повертаємо значення за замовчуванням
                return;
            }

            // Отримуємо координати кліка відносно Canvas
            Point click = e.GetPosition(GameCanvas);

            // КОРИГУЄМО КЛІК МИШІ:
            // Віднімаємо зсуви Canvas, щоб отримати логічні координати дошки.
            int cx = (int)Math.Floor((click.X - canvasOffsetX) / CellSize);
            int cy = (int)Math.Floor((click.Y - canvasOffsetY) / CellSize);

            Debug.WriteLine($"Клік за координатами Canvas: ({click.X}, {click.Y}), Логічні координати: ({cx}, {cy})");

            // Виконуємо хід, і якщо він успішний, комп'ютер робить свій хід (якщо режим проти комп'ютера).
            if (MakeMove(cx, cy, currentPlayer))
            {
                if (IsVsComputer())
                {
                    // Використовуємо Dispatcher, щоб комп'ютерний хід був після того, як UI оновиться.
                    Dispatcher.BeginInvoke(new Action(ComputerMove), DispatcherPriority.Render);
                }
            }
        }

        /// <summary>
        /// Виконує хід на задані координати для вказаного гравця.
        /// </summary>
        /// <returns>True, якщо хід успішний, False, якщо клітинка вже зайнята.</returns>
        private bool MakeMove(int x, int y, char player)
        {
            if (board.ContainsKey((x, y))) return false; // Клітинка вже зайнята

            board[(x, y)] = player; // Додаємо хід на дошку
            undoStack.Push(((x, y), player)); // Додаємо хід до стеку відміни
            redoStack.Clear(); // Очищаємо redo stack після нового ходу

            // Оновлюємо межі зайнятої області.
            // Ініціалізація min/maxBoardX/Y при першому ході, або розширення існуючих меж.
            if (board.Count == 1) // Це перший хід на дошці
            {
                minBoardX = x; maxBoardX = x;
                minBoardY = y; maxBoardY = y;
            }
            else
            {
                minBoardX = Math.Min(minBoardX, x);
                maxBoardX = Math.Max(maxBoardX, x);
                minBoardY = Math.Min(minBoardY, y);
                maxBoardY = Math.Max(maxBoardY, y);
            }
            Debug.WriteLine($"Зроблено хід: ({x}, {y}) для {player}. Межі: ({minBoardX},{minBoardY}) - ({maxBoardX},{maxBoardY})");

            RedrawBoardAndSymbols(); // Перемальовуємо все поле, щоб оновити сітку та символи

            // Перевірка на перемогу
            if (CheckWin(x, y, player)) // Перевіряємо виграш для останнього ходу
            {
                MessageBoxResult result = MessageBox.Show($"Гравець {player} переміг!\nПочати нову гру?", "Перемога!", MessageBoxButton.YesNo, MessageBoxImage.Information);
                if (result == MessageBoxResult.Yes)
                {
                    ResetGame();
                }
                else
                {
                    Close(); // Закриваємо гру
                }
                return true; // Гра закінчилася перемогою
            }

            // Перемикаємо гравця
            currentPlayer = player == 'X' ? 'O' : 'X';
            UpdateCurrentPlayerDisplay();
            return true; // Хід успішно зроблений
        }

        /// <summary>
        /// Виконує хід комп'ютера.
        /// </summary>
        private void ComputerMove()
        {
            if (currentPlayer != 'O') return; // Комп'ютер завжди грає за 'O'

            Debug.WriteLine("AI робить хід...");
            (int x, int y)? bestMove = FindBestMoveAI('O', 'X'); // Використовуємо функцію FindBestMoveAI
            if (bestMove != null)
            {
                MakeMove(bestMove.Value.x, bestMove.Value.y, 'O');
            }
            else
            {
                Debug.WriteLine("AI не зміг знайти хід. Це не повинно відбуватися, якщо є вільні клітинки.");
            }
        }

        /// <summary>
        /// Знаходить найкращий хід для AI-гравця, використовуючи Minimax.
        /// </summary>
        private (int x, int y)? FindBestMoveAI(char aiPlayer, char humanPlayer)
        {
            (int x, int y)? bestMove = null;
            int bestScore = int.MinValue;

            // Генеруємо всі можливі ходи
            var possibleMoves = GetFreeAdjacentCells().ToList();
            if (!possibleMoves.Any())
            {
                // Якщо поруч немає вільних клітинок, розглянемо ширший діапазон
                possibleMoves = GetEmptyCellsInExtendedRange().ToList();
            }

            // Спеціальний випадок: якщо дошка абсолютно пуста, і AI починає
            if (!possibleMoves.Any() && !board.Any())
            {
                return (0, 0); // Починаємо з центру
            }
            else if (!possibleMoves.Any()) // Якщо немає вільних клітинок взагалі
            {
                return null; // Немає куди ходити
            }

            // ШАГ 1: Перевіряємо, чи може AI виграти
            foreach (var pos in possibleMoves)
            {
                board[pos] = aiPlayer;
                if (CheckWin(pos.x, pos.y, aiPlayer)) // Перевіряємо перемогу відносно цього нового ходу
                {
                    board.Remove(pos);
                    return pos; // Знайшли виграшний хід
                }
                board.Remove(pos);
            }

            // ШАГ 2: Перевіряємо, чи потрібно блокувати гравця (людини)
            foreach (var pos in possibleMoves)
            {
                board[pos] = humanPlayer;
                if (CheckWin(pos.x, pos.y, humanPlayer)) // Перевіряємо, чи виграє гравець цим ходом
                {
                    board.Remove(pos);
                    return pos; // Блокуємо хід гравця
                }
                board.Remove(pos);
            }

            // ШАГ 3: Застосовуємо Minimax для решти ходів
            // Обмежимо глибину Minimax, щоб уникнути надмірних обчислень на великій дошці.
            int minimaxDepth = 2; // Можна збільшити, якщо потрібно "розумніший" бот (але уповільнить гру)

            // Перемішуємо ходи, щоб бот не завжди обирав одне й те саме, якщо є кілька рівноцінних ходів.
            foreach (var pos in possibleMoves.OrderBy(p => random.Next()))
            {
                board[pos] = aiPlayer;
                int score = Minimax(minimaxDepth, false); // false, бо далі хід гравця (мінімізатора)
                board.Remove(pos);

                if (score > bestScore)
                {
                    bestScore = score;
                    bestMove = pos;
                }
            }

            // Якщо Minimax не знайшов кращого ходу, або немає ходів, просто вибираємо випадкову вільну клітинку поблизу.
            if (bestMove == null && possibleMoves.Any())
            {
                return possibleMoves[random.Next(possibleMoves.Count)];
            }

            return bestMove;
        }

        /// <summary>
        /// Алгоритм Minimax для пошуку найкращого ходу.
        /// </summary>
        /// <param name="depth">Поточна глибина пошуку.</param>
        /// <param name="isMaximizingPlayer">True, якщо поточний гравець максимізує (AI), False, якщо мінімізує (людина).</param>
        /// <returns>Оцінка поточного стану дошки.</returns>
        private int Minimax(int depth, bool isMaximizingPlayer)
        {
            // Базовий випадок: досягнута максимальна глибина або гра закінчилася.
            if (CheckWinOverall(board, 'O')) return 10; // AI перемагає
            if (CheckWinOverall(board, 'X')) return -10; // Гравець перемагає
            if (depth == 0) return 0; // Досягнута межа глибини, повертаємо нейтральну оцінку.

            // Отримуємо потенційні ходи.
            var moves = GetFreeAdjacentCells().ToList();
            if (!moves.Any()) moves = GetEmptyCellsInExtendedRange().ToList();

            if (!moves.Any()) return 0; // Якщо взагалі немає ходів (що малоймовірно), нічия.

            int best = isMaximizingPlayer ? int.MinValue : int.MaxValue;

            foreach (var pos in moves)
            {
                if (isMaximizingPlayer)
                {
                    board[pos] = 'O'; // Спроба ходу AI
                    best = Math.Max(best, Minimax(depth - 1, false));
                }
                else
                {
                    board[pos] = 'X'; // Спроба ходу гравця
                    best = Math.Min(best, Minimax(depth - 1, true));
                }
                board.Remove(pos); // Скасувати віртуальний хід
            }

            return best;
        }

        /// <summary>
        /// Перевіряє, чи виграв гравець заданим символом на всьому полі (для Minimax).
        /// </summary>
        private bool CheckWinOverall(Dictionary<(int x, int y), char> currentBoard, char symbol)
        {
            foreach (var (x, y) in currentBoard.Keys.Where(k => currentBoard[k] == symbol))
            {
                // Перевіряємо 4 напрямки: горизонтальний, вертикальний, дві діагоналі.
                foreach (var (dx, dy) in new[] { (1, 0), (0, 1), (1, 1), (1, -1) })
                {
                    int count = 1; // Поточний символ
                    for (int i = 1; i < this.winLength; i++)
                    {
                        if (currentBoard.TryGetValue((x + dx * i, y + dy * i), out char val) && val == symbol)
                        {
                            count++;
                        }
                        else
                        {
                            break;
                        }
                    }
                    // Перевірка в протилежному напрямку (щоб порахувати повну лінію)
                    for (int i = 1; i < this.winLength; i++)
                    {
                        if (currentBoard.TryGetValue((x - dx * i, y - dy * i), out char val) && val == symbol)
                        {
                            count++;
                        }
                        else
                        {
                            break;
                        }
                    }

                    if (count >= this.winLength) return true;
                }
            }
            return false;
        }

        /// <summary>
        /// Повертає список вільних клітинок, сусідніх до вже зайнятих.
        /// </summary>
        private IEnumerable<(int x, int y)> GetFreeAdjacentCells()
        {
            HashSet<(int x, int y)> adjacentCells = new HashSet<(int x, int y)>();

            if (!board.Any())
            {
                // Якщо дошка порожня, даємо кілька початкових клітинок поблизу (0,0)
                // Це важливо для першого ходу бота, якщо він починає.
                for (int x = -1; x <= 1; x++)
                {
                    for (int y = -1; y <= 1; y++)
                    {
                        adjacentCells.Add((x, y));
                    }
                }
                return adjacentCells;
            }

            // Перебираємо всі зайняті клітинки
            foreach (var cell in board.Keys)
            {
                // Перевіряємо 3x3 квадрат навколо кожної зайнятої клітинки
                for (int dx = -1; dx <= 1; dx++)
                {
                    for (int dy = -1; dy <= 1; dy++)
                    {
                        if (dx == 0 && dy == 0) continue; // Пропускаємо саму клітинку

                        var adjacent = (cell.x + dx, cell.y + dy);
                        // Додаємо клітинку до результату, якщо вона порожня і ще не додана
                        if (!board.ContainsKey(adjacent))
                        {
                            adjacentCells.Add(adjacent);
                        }
                    }
                }
            }
            return adjacentCells;
        }

        /// <summary>
        /// Повертає список порожніх клітинок у розширеному діапазоні навколо зайнятих.
        /// Використовується як резерв, якщо GetFreeAdjacentCells() не знайде нічого.
        /// </summary>
        private IEnumerable<(int x, int y)> GetEmptyCellsInExtendedRange()
        {
            // Генеруємо порожні клітинки в розширеному діапазоні навколо зайнятих клітинок.
            int rangeBuffer = Math.Max(winLength, 5); // Буфер для пошуку, залежить від winLength
            for (int x = minBoardX - rangeBuffer; x <= maxBoardX + rangeBuffer; x++)
            {
                for (int y = minBoardY - rangeBuffer; y <= maxBoardY + rangeBuffer; y++)
                {
                    if (!board.ContainsKey((x, y)))
                    {
                        yield return (x, y);
                    }
                }
            }
        }

        /// <summary>
        /// Підраховує кількість послідовних символів заданого гравця в одному напрямку,
        /// враховуючи порожні клітинки як потенційні для розширення лінії.
        /// (Цей метод не використовується у поточній версії AI, але залишений для потенційного розширення)
        /// </summary>
        private int CountPotentialInDirection(int x, int y, int dx, int dy, char player)
        {
            int count = 0;
            // Перевіряємо вперед
            for (int i = 1; i < winLength; i++)
            {
                if (board.TryGetValue((x + dx * i, y + dy * i), out char c) && c == player)
                {
                    count++;
                }
                else if (board.ContainsKey((x + dx * i, y + dy * i)) && c != player)
                {
                    break; // Зустріли чужий символ, лінія перервана
                }
                else
                {
                    count++; // Порожня клітинка, вважаємо як потенційну частину лінії
                }
                if (count >= winLength) break;
            }
            // Перевіряємо назад
            for (int i = 1; i < winLength; i++)
            {
                if (board.TryGetValue((x - dx * i, y - dy * i), out char c) && c == player)
                {
                    count++;
                }
                else if (board.ContainsKey((x - dx * i, y - dy * i)) && c != player)
                {
                    break;
                }
                else
                {
                    count++;
                }
                if (count >= winLength) break;
            }
            return count + 1; // +1 за поточну клітинку
        }

        /// <summary>
        /// Перевіряє, чи грається режим "Гравець проти комп'ютера".
        /// </summary>
        private bool IsVsComputer()
        {
            // Безпечний доступ до SelectedItem та Content.
            return (GameModeBox?.SelectedItem as ComboBoxItem)?.Content?.ToString()?.Contains("комп'ютера") ?? false;
        }

        /// <summary>
        /// Обробник кліку по кнопці "Скасувати".
        /// </summary>
        private void Undo_Click(object sender, RoutedEventArgs e)
        {
            if (undoStack.Count == 0) return;

            var lastMove = undoStack.Pop();
            board.Remove(lastMove.pos);
            redoStack.Push(lastMove);

            // Якщо гра проти комп'ютера і останній хід був комп'ютера, також відміняємо його хід.
            if (IsVsComputer() && undoStack.Any() && undoStack.Peek().player == 'O')
            {
                var computerMove = undoStack.Pop();
                board.Remove(computerMove.pos);
                redoStack.Push(computerMove);
            }

            RedrawBoardAndSymbols();
            currentPlayer = lastMove.player; // Повертаємо хід попередньому гравцю
            UpdateCurrentPlayerDisplay();
        }

        /// <summary>
        /// Обробник кліку по кнопці "Повторити".
        /// </summary>
        private void Redo_Click(object sender, RoutedEventArgs e)
        {
            if (redoStack.Count == 0) return;

            var nextMove = redoStack.Pop();
            board[nextMove.pos] = nextMove.player;
            undoStack.Push(nextMove);

            // Якщо гра проти комп'ютера і наступний хід був комп'ютера, також повторюємо його хід.
            // Перевіряємо, чи наступний хід справді був комп'ютера (O)
            if (IsVsComputer() && nextMove.player == 'X' && redoStack.Any() && redoStack.Peek().player == 'O')
            {
                var computerMove = redoStack.Pop();
                board[computerMove.pos] = computerMove.player;
                undoStack.Push(computerMove);
            }
            RedrawBoardAndSymbols();
            currentPlayer = nextMove.player == 'X' ? 'O' : 'X'; // Перемикаємо гравця
            UpdateCurrentPlayerDisplay();
        }

        /// <summary>
        /// Скидає гру до початкового стану.
        /// </summary>
        private void ResetGame()
        {
            Debug.WriteLine("ResetGame: Called.");
            board.Clear();
            undoStack.Clear();
            redoStack.Clear();
            minBoardX = 0; maxBoardX = 0; minBoardY = 0; maxBoardY = 0;

            RedrawBoardAndSymbols(); // Малюємо чисту дошку

            currentPlayer = 'X';
            UpdateCurrentPlayerDisplay();

            // Якщо режим проти комп'ютера і комп'ютер починає (завжди 'O'),
            // дозволяємо йому зробити перший хід.
            if (IsVsComputer())
            {
                currentPlayer = 'O';
                UpdateCurrentPlayerDisplay();
                // Використовуємо Dispatcher, щоб UI встиг оновитися перед ходом AI
                Dispatcher.BeginInvoke(new Action(ComputerMove), DispatcherPriority.Render);
            }
        }

        /// <summary>
        /// Малює символ ('X' або 'O') на заданих координатах клітинки.
        /// </summary>
        private void DrawSymbol(int cx, int cy, char symbol)
        {
            if (GameCanvas == null)
            {
                Debug.WriteLine("[ERROR] DrawSymbol: GameCanvas is null. Cannot draw symbol.");
                return;
            }

            TextBlock tb = new TextBlock
            {
                Text = symbol.ToString(),
                FontSize = 24,
                FontWeight = FontWeights.Bold,
                Foreground = symbol == 'X' ? Brushes.Red : Brushes.Blue
            };

            // Вимірюємо розмір TextBlock, щоб відцентрувати його.
            tb.Measure(new Size(CellSize, CellSize));

            // Обчислюємо позицію для малювання символу, враховуючи зсув Canvas.
            double displayX = (cx * CellSize) + canvasOffsetX + (CellSize - tb.DesiredSize.Width) / 2;
            double displayY = (cy * CellSize) + canvasOffsetY + (CellSize - tb.DesiredSize.Height) / 2;

            Canvas.SetLeft(tb, displayX);
            Canvas.SetTop(tb, displayY);

            GameCanvas.Children.Add(tb);
        }

        /// <summary>
        /// Перемальовує всю дошку та всі символи.
        /// Викликається після кожного ходу, відміни/повтору, або при скиданні гри.
        /// </summary>
        private void RedrawBoardAndSymbols()
        {
            if (GameCanvas == null)
            {
                Debug.WriteLine("[ERROR] RedrawBoardAndSymbols: GameCanvas is null. Returning.");
                return;
            }
            DrawBoardGrid(); // Спочатку малюємо оновлену сітку
            foreach (var cell in board) // Потім малюємо всі символи на дошці
            {
                DrawSymbol(cell.Key.x, cell.Key.y, cell.Value);
            }
            Debug.WriteLine($"RedrawBoardAndSymbols: Board has {board.Count} symbols.");
        }

        /// <summary>
        /// Перевіряє, чи гравець виграв після останнього ходу.
        /// </summary>
        private bool CheckWin(int x, int y, char player)
        {
            // Перевіряємо 4 напрямки: горизонтальний, вертикальний, дві діагоналі.
            if (CountInDirection(x, y, 1, 0, player) + CountInDirection(x, y, -1, 0, player) + 1 >= winLength) return true; // Горизонталь
            if (CountInDirection(x, y, 0, 1, player) + CountInDirection(x, y, 0, -1, player) + 1 >= winLength) return true; // Вертикаль
            if (CountInDirection(x, y, 1, 1, player) + CountInDirection(x, y, -1, -1, player) + 1 >= winLength) return true; // Діагональ (зліва зверху доправа знизу)
            if (CountInDirection(x, y, -1, 1, player) + CountInDirection(x, y, 1, -1, player) + 1 >= winLength) return true; // Діагональ (справа зверху доліва знизу)

            return false;
        }

        /// <summary>
        /// Підраховує кількість послідовних символів заданого гравця в одному напрямку.
        /// </summary>
        private int CountInDirection(int x, int y, int dx, int dy, char player)
        {
            int count = 0;
            for (int i = 1; i < winLength; i++)
            {
                if (board.TryGetValue((x + dx * i, y + dy * i), out char c) && c == player)
                {
                    count++;
                }
                else
                {
                    break; // Перервати, якщо зустріли порожню клітинку або чужий символ
                }
            }
            return count;
        }

        /// <summary>
        /// Оновлює відображення поточного гравця у TextBlock.
        /// </summary>
        private void UpdateCurrentPlayerDisplay()
        {
            if (CurrentPlayerTextBlock != null) // Завжди перевіряємо на null
            {
                CurrentPlayerTextBlock.Text = currentPlayer.ToString();
                CurrentPlayerTextBlock.Foreground = currentPlayer == 'X' ? Brushes.Red : Brushes.Blue;
            }
            else
            {
                Debug.WriteLine("[ERROR] UpdateCurrentPlayerDisplay: CurrentPlayerTextBlock is null.");
            }
        }

        /// <summary>
        /// Обробник зміни режиму гри.
        /// </summary>
        private void GameModeBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (GameModeBox != null) // Перевірка на null для безпеки
            {
                ResetGame();
            }
        }

        /// <summary>
        /// Обробник зміни тексту в полі довжини для перемоги.
        /// </summary>
        private void WinLengthBox_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (WinLengthBox == null) return; // Перевірка на null для безпеки

            if (!int.TryParse(WinLengthBox.Text, out int length) || length < 3)
            {
                WinLengthBox.BorderBrush = Brushes.Red;
                WinLengthBox.ToolTip = "Довжина для перемоги має бути числом більше або рівним 3.";
            }
            else
            {
                WinLengthBox.BorderBrush = Brushes.Gray;
                WinLengthBox.ToolTip = null;
                winLength = length;
            }
        }
    }
}